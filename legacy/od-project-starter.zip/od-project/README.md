# Object Detection Starter (YOLOv8 • PyTorch)

## 1) Setup
```bash
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## 2) Quick demo on coco128
```bash
python src/train.py --config configs/yolo_coco128.yaml
python src/evaluate.py --config configs/yolo_coco128.yaml --ckpt outputs/train/weights/best.pt
python src/predict.py --config configs/yolo_coco128.yaml --ckpt outputs/train/weights/best.pt --source ultralytics/assets
```

## 3) Use your own dataset
- Fill `data/data.yaml` from `data/data.template.yaml`, place images/labels under `data/images/...` and `data/labels/...`.
- Switch to `configs/yolo_custom.yaml`.

## Notes
- Use a T4 GPU (Colab/Kaggle). Increase `epochs` for real training.
- Metrics saved to `outputs/metrics.json`, eval to `outputs/eval.json`.
