# CV Classification Starter (PyTorch)

## 1) Setup
```bash
python -m venv .venv && source .venv/bin/activate  # win: .venv\Scripts\activate
pip install -r requirements.txt
```

## 2) Train
```bash
python src/train.py --config configs/cv_cifar10.yaml
```
Artifacts are written to `outputs/`: `best.pt`, `log.csv`, `metrics.json`.

## 3) Evaluate
```bash
python src/evaluate.py --config configs/cv_cifar10.yaml --ckpt outputs/best.pt
```
Produces `eval.json` and `confusion_matrix.png`.

## 4) Switch to your own images
- Put class subfolders under `data/` like `data/cats/`, `data/dogs/`, …
- In `configs/cv_cifar10.yaml`, set:
```yaml
data:
  dataset: imagefolder
  root: ./data
  val_split: 0.1
```
