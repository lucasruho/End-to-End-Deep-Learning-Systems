import argparse, json
from pathlib import Path
import torch, matplotlib.pyplot as plt
from torchmetrics.classification import MulticlassAccuracy, ConfusionMatrix

from utils import load_yaml
from data import build_dataloaders
from model import build_model

@torch.no_grad()
def main(cfg_path, ckpt_path):
    cfg = load_yaml(cfg_path)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    _, val_loader, num_classes, classes = build_dataloaders(cfg)

    model = build_model(cfg, num_classes)
    model.load_state_dict(torch.load(ckpt_path, map_location=device))
    model.to(device).eval()

    acc_metric = MulticlassAccuracy(num_classes=num_classes).to(device)
    cm_metric  = ConfusionMatrix(num_classes=num_classes).to(device)

    for x, y in val_loader:
        x, y = x.to(device), y.to(device)
        logits = model(x)
        acc_metric.update(logits, y); cm_metric.update(logits, y)

    acc = acc_metric.compute().item()
    cm  = cm_metric.compute().cpu().numpy()

    out = Path(cfg["output_dir"]); out.mkdir(parents=True, exist_ok=True)
    with open(out / "eval.json", "w") as f:
        json.dump({"val_acc": acc, "classes": classes}, f, indent=2)

    fig, ax = plt.subplots(figsize=(6,6))
    im = ax.imshow(cm, interpolation="nearest", cmap="Blues")
    ax.set_title("Confusion matrix"); fig.colorbar(im, ax=ax)
    ax.set_xticks(range(num_classes)); ax.set_yticks(range(num_classes))
    ax.set_xticklabels(classes, rotation=45, ha="right"); ax.set_yticklabels(classes)
    ax.set_xlabel("Predicted"); ax.set_ylabel("True")
    for i in range(num_classes):
        for j in range(num_classes):
            ax.text(j, i, int(cm[i, j]), ha="center", va="center", color="black", fontsize=8)
    fig.tight_layout(); fig.savefig(out / "confusion_matrix.png", dpi=200)
    print(f"Accuracy: {acc:.4f}. Saved confusion_matrix.png and eval.json in {out}")

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--config", type=str, default="configs/cv_cifar10.yaml")
    p.add_argument("--ckpt",   type=str, default="outputs/best.pt")
    a = p.parse_args()
    main(a.config, a.ckpt)
