# NLP Text Classification Starter (PyTorch • LSTM)

## 1) Setup
```bash
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## 2) Train on **AG News**
```bash
python src/train.py --config configs/nlp_agnews.yaml
```
Artifacts: `outputs/best.pt`, `outputs/log.csv`, `outputs/metrics.json`.

## 3) Evaluate (val/test)
```bash
python src/evaluate.py --config configs/nlp_agnews.yaml --ckpt outputs/best.pt
```
Writes `outputs/eval.json` with accuracy and macro-F1.

## 4) Predict on your texts
Create `texts.json` as a JSON list of strings:
```json
["Apple unveils new chip", "The team won the match"]
```
Run:
```bash
python src/predict.py --ckpt outputs/best.pt --texts texts.json
```

## 5) Use your own CSV
- Put CSV files and set in `configs/nlp_agnews.yaml`:
```yaml
data:
  dataset: csv
  train_csv: data/train.csv
  val_csv: data/val.csv
  test_csv: data/test.csv     # optional
  text_col: text
  label_col: label            # strings or 0..C-1
  delimiter: ","
```
- Labels that are strings will be mapped automatically to IDs in alphabetical order.

## Notes
- Simple regex tokenizer and vocab built from train set.
- LSTM with packing, dropout, bidirectional option, CrossEntropy, AdamW.
- Early stopping on macro-F1, optional cosine LR scheduler.
