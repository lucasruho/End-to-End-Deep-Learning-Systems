# Time-series / Tabular Regression Starter (PyTorch)

## 1) Setup
```bash
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## 2) Tabular regression (MLP)
- Put a CSV at `data/train.csv` with a numeric column `target` and numeric feature columns.
- Edit `configs/reg_tabular_mlp.yaml` if needed.
```bash
python src/train.py --config configs/reg_tabular_mlp.yaml
python src/evaluate.py --config configs/reg_tabular_mlp.yaml --ckpt outputs/best.pt
```

## 3) Time-series regression (LSTM)
- Put a CSV at `data/series.csv` with a time column `timestamp`, numeric `target`, and numeric features.
- Edit `configs/reg_timeseries_lstm.yaml` (set `seq_len`, `horizon`).
```bash
python src/train.py --config configs/reg_timeseries_lstm.yaml
python src/evaluate.py --config configs/reg_timeseries_lstm.yaml --ckpt outputs/best.pt
```

## 4) Predict
```bash
python src/predict.py --ckpt outputs/best.pt --csv path/to/file.csv --features "f1,f2,f3"
# or for time-series windows:
python src/predict.py --ckpt outputs/best.pt --csv path/to/series.csv --features "f1,f2" --timeseries --seq_len 48
```

## Notes
- Standardization is fit on train only and stored with the checkpoint.
- Metrics: MSE, MAE, R^2. Early stopping on validation MSE.
- For time-series, splits are chronological; for tabular, random with seed.
