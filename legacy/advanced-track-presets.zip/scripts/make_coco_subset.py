
# scripts/make_coco_subset.py
# Create a smaller COCO subset in YOLO format at data/coco50p.
# This is a placeholder; in practice parse COCO JSONs and sample images/annotations by fraction.
