
# scripts/make_imagenet_subset.py
# Stub: copy a curated list of classes from ImageNet to data/imagenet_subset/{train,val}
# Provide your own mapping/list; this script is a placeholder for course ops.
